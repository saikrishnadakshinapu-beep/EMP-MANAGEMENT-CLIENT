import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'emp-mng';
  contactForm = new FormGroup({
    mobile: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required]
    }),
    email: new FormControl('', {
      nonNullable: true,
      validators: [Validators.email]
    })
  });
  submittedContactDetails: { mobile: string; email: string } | null = null;

  onSubmit(): void {
    if (this.contactForm.invalid) {
      this.contactForm.markAllAsTouched();
      return;
    }
    this.submittedContactDetails = this.contactForm.getRawValue();
    console.log('Submitted Contact Details:', this.submittedContactDetails);
  }
}
